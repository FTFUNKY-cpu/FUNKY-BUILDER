Gradle wrapper properties are configured. Generate wrapper scripts and the wrapper JAR with a local Gradle install using: gradle wrapper --gradle-version 9.6.0
