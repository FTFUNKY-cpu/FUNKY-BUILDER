package com.funkybuilder.config;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

/** Creates a readable default configuration without overwriting user settings. */
public final class BuilderConfig {
    private BuilderConfig() {}

    public static void createTemplateIfMissing(Path configDir) throws IOException {
        Files.createDirectories(configDir);
        Path file = configDir.resolve("funky-builder.json");
        if (Files.exists(file)) return;
        String json = """
            {
              "buildSpeedBlocksPerSecond": 2,
              "layerByLayer": true,
              "ignoreAir": true,
              "replaceExistingBlocks": false,
              "rotation": 0,
              "mirror": "NONE",
              "placementDelayTicks": 4,
              "showNotifications": true,
              "previewBeforeBuild": true
            }
            """;
        Files.writeString(file, json);
    }
}
