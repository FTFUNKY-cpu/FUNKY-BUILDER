package com.funkybuilder;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

public final class FunkyBuilder implements ModInitializer {
    public static final String MOD_ID = "funky_builder";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static Path schematicDirectory;

    @Override
    public void onInitialize() {
        schematicDirectory = FabricLoader.getInstance()
                .getConfigDir()
                .resolve("funky-builder")
                .resolve("schematics");

        try {
            Files.createDirectories(schematicDirectory);
            LOGGER.info("FUNKY BUILDER initialized.");
            LOGGER.info("Put supported schematic files in: {}", schematicDirectory);
        } catch (IOException exception) {
            LOGGER.error("Could not create the schematic folder.", exception);
        }
    }

    public static Path getSchematicDirectory() {
        if (schematicDirectory == null) {
            throw new IllegalStateException("FUNKY BUILDER has not initialized yet.");
        }
        return schematicDirectory;
    }
}
