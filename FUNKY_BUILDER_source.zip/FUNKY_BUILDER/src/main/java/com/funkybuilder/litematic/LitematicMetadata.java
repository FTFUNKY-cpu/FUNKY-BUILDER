package com.funkybuilder.litematic;

/** Metadata extracted from a Litematica file. */
public record LitematicMetadata(
    String name, int width, int height, int length, long totalBlocks
) {}
