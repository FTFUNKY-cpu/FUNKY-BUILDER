package com.funkybuilder.litematic;

/**
 * Litematica files are gzip-compressed Minecraft NBT.
 * Regions contain Position, Size, BlockStatePalette and packed BlockStates.
 * BlockStates are packed palette indices, not one integer per block.
 * A complete importer must handle bit widths, values crossing long boundaries,
 * negative region sizes, multiple regions and optional block entity data.
 */
public final class LitematicFormatNotes {
    private LitematicFormatNotes() {}
    public static final String EXTENSION = ".litematic";
}
