package com.funkybuilder.schematic;

import com.funkybuilder.FunkyBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Discovers schematic files in config/funky-builder/schematics.
 *
 * NBT decoding and palette/block-state conversion are intentionally left
 * for the next implementation milestone. This class does not modify worlds.
 */
public final class SchematicLoader {
    private SchematicLoader() {}

    public static List<SchematicFile> findAvailableSchematics() throws IOException {
        Path directory = FunkyBuilder.getSchematicDirectory();

        try (var paths = Files.list(directory)) {
            return paths
                    .filter(Files::isRegularFile)
                    .filter(SchematicLoader::hasSupportedExtension)
                    .sorted(Comparator.comparing(path ->
                            path.getFileName().toString().toLowerCase(Locale.ROOT)))
                    .map(path -> new SchematicFile(
                            path,
                            path.getFileName().toString(),
                            SchematicFile.Format.fromPath(path)))
                    .toList();
        }
    }

    private static boolean hasSupportedExtension(Path path) {
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        return name.endsWith(".schem") || name.endsWith(".schematic");
    }
}
