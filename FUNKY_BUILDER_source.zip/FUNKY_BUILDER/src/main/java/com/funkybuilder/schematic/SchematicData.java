package com.funkybuilder.schematic;

/**
 * Neutral data model for a decoded schematic.
 * Coordinates are local to the schematic origin.
 *
 * The next milestone will populate this model from Sponge/legacy NBT files.
 */
public record SchematicData(
        int width,
        int height,
        int length,
        int paletteSize,
        int nonAirBlockCount
) {
    public SchematicData {
        if (width < 1 || height < 1 || length < 1) {
            throw new IllegalArgumentException("Schematic dimensions must be positive.");
        }
        if (paletteSize < 0 || nonAirBlockCount < 0) {
            throw new IllegalArgumentException("Block counts cannot be negative.");
        }
    }

    public long volume() {
        return (long) width * height * length;
    }
}
