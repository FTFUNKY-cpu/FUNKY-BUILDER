package com.funkybuilder.schematic;

import java.nio.file.Path;

public record SchematicFile(Path path, String displayName, Format format) {
    public enum Format {
        SPONGE_SCHEMATIC(".schem"),
        LEGACY_SCHEMATIC(".schematic");

        private final String extension;

        Format(String extension) {
            this.extension = extension;
        }

        public String extension() {
            return extension;
        }

        public static Format fromPath(Path path) {
            String name = path.getFileName().toString().toLowerCase();
            for (Format format : values()) {
                if (name.endsWith(format.extension)) {
                    return format;
                }
            }
            throw new IllegalArgumentException("Unsupported schematic extension: " + name);
        }
    }
}
