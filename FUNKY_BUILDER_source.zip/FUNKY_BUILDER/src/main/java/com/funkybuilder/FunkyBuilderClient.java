package com.funkybuilder;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.text.Text;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

/** Client entry point for FUNKY BUILDER. */
public final class FunkyBuilderClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("funkybuilder")
                .then(literal("help").executes(context -> {
                    context.getSource().sendFeedback(Text.literal(
                        "FUNKY BUILDER: /funkybuilder help | /funkybuilder config"));
                    return 1;
                }))
                .then(literal("config").executes(context -> {
                    context.getSource().sendFeedback(Text.literal(
                        "Config template: config/funky-builder.json"));
                    return 1;
                }))
            )
        );
    }
}
