package com.funkybuilder.client;

import net.fabricmc.api.ClientModInitializer;
import com.funkybuilder.FunkyBuilder;

public final class FunkyBuilderClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FunkyBuilder.LOGGER.info("FUNKY BUILDER client components are ready.");
    }
}
