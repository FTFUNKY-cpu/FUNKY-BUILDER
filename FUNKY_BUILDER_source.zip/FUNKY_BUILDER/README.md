# FUNKY BUILDER

A client-side Fabric mod starter project for Minecraft Java 26.3.

## Current starter milestone

- Fabric mod metadata and entrypoints
- Minecraft 26.3 / Java 25 / Fabric API dependency configuration
- Creates `config/funky-builder/schematics`
- Finds `.schem` and `.schematic` files in that folder
- Defines a basic schematic data model

## Not implemented yet

This is a starter foundation, not a finished schematic printer. It does **not**
decode NBT schematic contents, render a hologram, or place blocks yet.

The next milestones are:
1. Add Sponge `.schem` NBT decoding and legacy `.schematic` support.
2. Add an in-game file browser and schematic preview screen.
3. Add rotation, positioning, and missing-material calculations.
4. Add a placement-assistance workflow that uses ordinary server-approved
   interactions only. It must respect server rules, permissions, and rate limits.

## Requirements

- Minecraft Java 26.3
- Fabric Loader 0.19.5 or newer
- Fabric API 0.165.0+26.3
- Java Development Kit 25
- Gradle wrapper distribution 9.6.0

Fabric's recommended versions can change. Check https://fabricmc.net/develop/
before updating dependencies.

## Build

From this project folder, run with Gradle 9.6.0 installed:

```bash
gradle build
```

To generate a Gradle wrapper on your computer first, run:

```bash
gradle wrapper --gradle-version 9.6.0
```

Then you can use `./gradlew build` (or `gradlew.bat build` on Windows).

The built mod JAR will be in:

```text
build/libs/
```

## Install

Copy the built `funky-builder-0.1.0.jar` into the `mods` folder of the
Minecraft 26.3 Fabric instance. Install the matching Fabric API as well.

The mod creates its schematic folder under the Minecraft config directory:

```text
config/funky-builder/schematics/
```

Place schematic files there. File discovery is implemented; decoding and
preview will arrive in the next milestone.

## Multiplayer note

FUNKY BUILDER is designed as a client-side building assistant. It does not
bypass server permissions, anti-cheat, block protections, or placement limits.
Only use building assistance where the server permits it.
