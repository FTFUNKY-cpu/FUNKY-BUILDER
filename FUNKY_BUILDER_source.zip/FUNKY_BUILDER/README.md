# FUNKY BUILDER

Fabric client mod project for importing **Litematica `.litematic`** blueprints.

## Included in this starter

- Fabric client entry point and `/funkybuilder` help/config commands
- Configuration JSON template class
- Litematica metadata model and format implementation notes
- Gradle project setup
- GitHub Actions build workflow

## Important status

This is an **initial scaffold, not a finished automatic builder**. It does not
yet decode packed Litematica block-state arrays, draw the hologram preview, or
place blocks. Those features need implementation and testing against the exact
Minecraft/Fabric 26.3 mappings and a real `.litematic` sample. Construction
must use normal player interactions and respect server permissions, reach,
inventory and game mode.

## Build

1. Verify the Minecraft 26.3 Yarn, Fabric Loader, Fabric API and Loom versions
   in `gradle.properties` against official Fabric documentation.
2. Install JDK 21 and Gradle.
3. Run `gradle wrapper`.
4. Run `./gradlew build` (Windows: `gradlew.bat build`).
5. The JAR will be in `build/libs/`.

The version coordinates are starter values and may need adjustment if matching
Fabric 26.3 artifacts are not published.

## Planned schematic folder

`config/funky-builder/schematics/`

## Planned settings

| Setting | Default |
|---|---:|
| Build speed | 2 blocks/sec |
| Layer-by-layer | On |
| Ignore air | On |
| Replace existing blocks | Off |
| Rotation | 0° |
| Mirror | None |
| Placement delay | 4 ticks |
| Notifications | On |
| Preview before build | On |

## Planned controls

Load blueprint; preview/hide; start/pause/resume/stop; rotate/mirror; show
missing-block and progress counts.
