package com.example.schematicbuilder.planner;

import com.example.schematicbuilder.schematic.Schematic;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.item.BlockItem;
import net.minecraft.state.property.Properties;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;

import java.util.*;

/** A schematic placed in the world: rotated, mirrored, grouped into layers (bottom to top). */
public final class BuildPlan {
    public final String name;
    public final BlockPos origin;
    public final int rotation;
    public final boolean mirror;
    public final TreeMap<Integer, List<Target>> layers = new TreeMap<>();
    public final Map<BlockPos, Target> byPos = new HashMap<>();
    public final List<String> warnings = new ArrayList<>();
    public final Box bounds;

    public BuildPlan(Schematic s, BlockPos origin, int rotation, boolean mirror) {
        this.name = s.name();
        this.origin = origin;
        this.rotation = ((rotation % 4) + 4) % 4;
        this.mirror = mirror;
        BlockRotation br = BlockRotation.values()[this.rotation]; // NONE, CW90, CW180, CCW90

        List<BlockPos> ps = new ArrayList<>();
        List<BlockState> ss = new ArrayList<>();
        int minX = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        for (Schematic.Entry e : s.blocks()) {
            BlockPos p = e.pos();
            BlockState st = e.state();
            if (mirror) {
                p = new BlockPos(-p.getX(), p.getY(), p.getZ());
                st = st.mirror(BlockMirror.FRONT_BACK);
            }
            p = p.rotate(br);
            st = st.rotate(br);
            ps.add(p);
            ss.add(st);
            minX = Math.min(minX, p.getX());
            minZ = Math.min(minZ, p.getZ());
        }

        int doubleSlabs = 0, noItem = 0;
        double bx0 = Double.MAX_VALUE, by0 = Double.MAX_VALUE, bz0 = Double.MAX_VALUE;
        double bx1 = -Double.MAX_VALUE, by1 = -Double.MAX_VALUE, bz1 = -Double.MAX_VALUE;
        for (int i = 0; i < ps.size(); i++) {
            BlockPos p = ps.get(i);
            BlockState st = ss.get(i);
            BlockPos wp = origin.add(p.getX() - minX, p.getY(), p.getZ() - minZ);
            Target t = new Target(wp, st);
            Block b = st.getBlock();
            if (!(b.asItem() instanceof BlockItem)) {
                t.hard = true;
                noItem++;
            } else if (b instanceof SlabBlock && st.get(SlabBlock.TYPE) == SlabType.DOUBLE) {
                t.hard = true;
                doubleSlabs++;
            } else if (isSecondHalf(st)) {
                t.auto = true;
            }
            layers.computeIfAbsent(wp.getY(), k -> new ArrayList<>()).add(t);
            byPos.put(wp, t);
            bx0 = Math.min(bx0, wp.getX()); by0 = Math.min(by0, wp.getY()); bz0 = Math.min(bz0, wp.getZ());
            bx1 = Math.max(bx1, wp.getX() + 1); by1 = Math.max(by1, wp.getY() + 1); bz1 = Math.max(bz1, wp.getZ() + 1);
        }
        if (doubleSlabs > 0) warnings.add(doubleSlabs + " double slabs (not supported yet)");
        if (noItem > 0) warnings.add(noItem + " blocks without an item form (fluids, fire...)");
        bounds = ps.isEmpty() ? new Box(origin) : new Box(bx0, by0, bz0, bx1, by1, bz1);
    }

    private static boolean isSecondHalf(BlockState st) {
        return (st.contains(Properties.DOUBLE_BLOCK_HALF) && st.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER)
                || (st.contains(Properties.BED_PART) && st.get(Properties.BED_PART) == BedPart.HEAD);
    }
}
