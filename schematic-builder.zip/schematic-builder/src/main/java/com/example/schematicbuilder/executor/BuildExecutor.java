package com.example.schematicbuilder.executor;

import com.example.schematicbuilder.SchematicBuilderMod;
import com.example.schematicbuilder.config.BuilderConfig;
import com.example.schematicbuilder.inventory.InventoryHelper;
import com.example.schematicbuilder.planner.BuildPlan;
import com.example.schematicbuilder.planner.PlacementSolver;
import com.example.schematicbuilder.planner.ScaffoldPlanner;
import com.example.schematicbuilder.planner.StateMatcher;
import com.example.schematicbuilder.planner.Target;
import com.example.schematicbuilder.schematic.Schematic;
import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.util.InputUtil;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * Tick-based state machine.
 *   PICK -> ASSESS -> (BREAK_TEMP) -> SELECT_ITEM -> MOVE -> ROTATE -> PLACE_TEMP/PLACE_BLOCK -> VERIFY -> ...
 * Temporary scaffold blocks are tracked in activeScaffolds and always removed on pause/stop/finish/error.
 */
public final class BuildExecutor {
    public enum Mode { IDLE, RUNNING, PAUSING, PAUSED, STOPPING }
    public enum State { IDLE, PICK, ASSESS, SELECT_ITEM, MOVE, ROTATE, PLACE_TEMP, PLACE_BLOCK, BREAK_TEMP, VERIFY }

    private MinecraftClient mc;
    private Schematic schematic;
    private BlockPos origin;
    private int rotation;
    private boolean mirror;
    private BuildPlan plan;

    private Mode mode = Mode.IDLE;
    private State state = State.IDLE;
    private State afterBreak = State.ASSESS;
    private String stopMessage = "";

    private Target cur;
    private BlockPos jobPos;
    private BlockState jobState;
    private boolean jobTemp;
    private Item jobItem;
    private PlacementSolver.Solution sol;

    private final Deque<BlockPos> scaffoldQueue = new ArrayDeque<>();
    private final List<BlockPos> activeScaffolds = new ArrayList<>();
    private final Deque<BlockPos> breakQueue = new ArrayDeque<>();
    private final List<BlockPos> leftovers = new ArrayList<>();
    private BlockPos breakingPos;
    private boolean breaking;

    private int cooldown, waitTicks, moveTicks, verifyTicks, sweepPass, tickCount;
    private float lastHealth;

    // stats for HUD / overlay (refreshed once a second)
    private int statTotal, statDone;
    private List<BlockPos> preview = List.of();
    private Map<String, Integer> missing = Map.of();

    private static BuilderConfig cfg() { return SchematicBuilderMod.config; }

    // ================================================================= public API
    public boolean load(MinecraftClient client, Schematic s) {
        if (mode != Mode.IDLE) return false;
        mc = client;
        schematic = s;
        origin = client.player.getBlockPos();
        rotation = 0;
        mirror = false;
        rebuild();
        return true;
    }

    public boolean setOrigin(BlockPos p) { if (!editable()) return false; origin = p; rebuild(); return true; }
    public boolean setRotation(int quarterTurns) { if (!editable()) return false; rotation = quarterTurns; rebuild(); return true; }
    public boolean toggleMirror() { if (!editable()) return false; mirror = !mirror; rebuild(); return true; }
    private boolean editable() { return mode == Mode.IDLE && schematic != null && origin != null; }

    private void rebuild() {
        plan = new BuildPlan(schematic, origin, rotation, mirror);
        sweepPass = 0;
        cur = null;
        refreshStats();
    }

    /** @return an error message, or null when started. */
    public String start(MinecraftClient client) {
        mc = client;
        if (plan == null) return "Load a schematic first: /build load <file>";
        if (mode != Mode.IDLE) return "Already active. Use /build resume or /build stop.";
        rebuild();
        mode = Mode.RUNNING;
        state = State.PICK;
        lastHealth = client.player.getHealth();
        cooldown = 0;
        return null;
    }

    public void pause() { requestPause("paused by command"); }

    public String resume(MinecraftClient client) {
        mc = client;
        if (mode != Mode.PAUSED) return "Nothing to resume.";
        mode = Mode.RUNNING;
        state = State.PICK;
        cur = null;
        lastHealth = client.player.getHealth();
        return null;
    }

    public void stop() {
        if (mode == Mode.IDLE) return;
        if (mode == Mode.PAUSED) { mode = Mode.IDLE; state = State.IDLE; msg("Stopped."); return; }
        stopMessage = "Stopped.";
        if (mode == Mode.RUNNING) { mode = Mode.STOPPING; beginCleanup(); } else mode = Mode.STOPPING;
    }

    public void onDisconnect() { forceIdle(); activeScaffolds.clear(); }

    public Mode mode() { return mode; }
    public State state() { return state; }
    public BuildPlan plan() { return plan; }
    public int statTotal() { return statTotal; }
    public int statDone() { return statDone; }
    public List<BlockPos> preview() { return preview; }
    public List<BlockPos> scaffolds() { return activeScaffolds; }
    public Map<String, Integer> missing() { return missing; }
    public Target current() { return cur; }

    public String status() {
        return mode + "/" + state + " - " + statDone + "/" + statTotal + " blocks"
                + (cur != null ? " - layer y=" + cur.pos.getY() : "");
    }

    // ================================================================= tick
    public void tick(MinecraftClient client) {
        mc = client;
        if (client.player == null || client.world == null || client.interactionManager == null) {
            if (mode != Mode.IDLE) forceIdle();
            return;
        }
        if (plan != null && ++tickCount % 20 == 0) refreshStats();
        if (mode == Mode.IDLE || mode == Mode.PAUSED) return;
        try {
            if (mode == Mode.RUNNING && shouldPause()) return;
            if (cooldown > 0) { cooldown--; return; }
            for (int i = 0; i < Math.max(1, cfg().maxStepsPerTick); i++) {
                if (!step()) break;
            }
        } catch (Throwable t) {
            SchematicBuilderMod.LOG.error("Builder error", t);
            msg("Error: " + t + " - removing temporary blocks.");
            if (mode == Mode.STOPPING) {
                forceIdle();
                reportLeftovers();
            } else {
                stopMessage = "Stopped after an error.";
                mode = Mode.STOPPING;
                beginCleanup();
            }
        }
    }

    private boolean shouldPause() {
        ClientPlayerEntity p = mc.player;
        float hp = p.getHealth();
        boolean hurt = hp < lastHealth - 0.01f;
        lastHealth = hp;
        if (cfg().pauseOnDamage && hurt) { requestPause("you took damage"); return true; }
        if (cfg().pauseOnScreen && mc.currentScreen != null) { requestPause("a screen was opened"); return true; }
        if (cfg().pauseOnManualMove && mc.currentScreen == null) {
            long h = mc.getWindow().getHandle();
            if (InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_W) || InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_A)
                    || InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_S) || InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_D)
                    || InputUtil.isKeyPressed(h, GLFW.GLFW_KEY_SPACE)) {
                requestPause("manual movement");
                return true;
            }
        }
        return false;
    }

    // ================================================================= state machine
    private boolean step() {
        ClientWorld w = mc.world;
        switch (state) {
            case PICK -> {
                Target t = pickNext();
                if (t == null) return finishOrSweep();
                cur = t;
                // drop scaffolds that the next target can't reuse
                for (BlockPos s : activeScaffolds) {
                    if (s.getManhattanDistance(t.pos) > 1 && !breakQueue.contains(s)) breakQueue.add(s);
                }
                if (!breakQueue.isEmpty()) startBreaking(State.ASSESS); else state = State.ASSESS;
                return true;
            }
            case ASSESS -> { return assess(w); }
            case SELECT_ITEM -> {
                if (InventoryHelper.ensureInHand(mc, jobItem)) {
                    state = State.MOVE;
                    moveTicks = 0;
                    sol = null;
                    return true;
                }
                requestPause("missing " + jobItem.getName().getString());
                return false;
            }
            case MOVE -> {
                if (moveTicks % 3 == 0) sol = solveJob(true);
                if (sol != null) {
                    releaseKeys();
                    state = State.ROTATE;
                    waitTicks = 0;
                    return true;
                }
                walkToward(Vec3d.ofCenter(jobPos));
                if (++moveTicks > 200) {
                    releaseKeys();
                    jobFailed("could not get within reach of " + jobPos.toShortString());
                }
                return false;
            }
            case ROTATE -> {
                if (sol == null) { state = State.MOVE; return true; }
                if (waitTicks == 0) {
                    // Rotation + sneak are sent to the server with this tick's movement packet.
                    // Sneaking stops right-click interactions (chests etc.) on the support block.
                    mc.player.setYaw(sol.yaw());
                    mc.player.setPitch(sol.pitch());
                    mc.options.sneakKey.setPressed(true);
                    waitTicks = 1;
                    return false;
                }
                state = jobTemp ? State.PLACE_TEMP : State.PLACE_BLOCK;
                return true;
            }
            case PLACE_TEMP, PLACE_BLOCK -> {
                if (!mc.player.getMainHandStack().isOf(jobItem)) { state = State.SELECT_ITEM; return true; }
                BlockHitResult hr = new BlockHitResult(sol.hit(), sol.face(), sol.support(), false);
                ActionResult r = mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hr);
                if (r.isAccepted()) mc.player.swingHand(Hand.MAIN_HAND);
                mc.options.sneakKey.setPressed(false);
                verifyTicks = 0;
                state = State.VERIFY;
                return false;
            }
            case VERIFY -> {
                if (++verifyTicks < cfg().verifyDelayTicks) return false;
                BlockState now = w.getBlockState(jobPos);
                boolean ok = jobTemp ? now.isOf(jobState.getBlock()) : StateMatcher.matches(now, jobState);
                cooldown = cfg().placeDelayTicks;
                if (ok) onJobSuccess(); else jobFailed("placement at " + jobPos.toShortString() + " was not confirmed");
                return false;
            }
            case BREAK_TEMP -> { return breakStep(w); }
            default -> { return false; }
        }
    }

    // ---------------------------------------------------------------- choosing targets
    private Target pickNext() {
        ClientWorld w = mc.world;
        Vec3d pp = mc.player.getPos();
        for (List<Target> layer : plan.layers.values()) {
            Target best = null;
            double bestScore = Double.MAX_VALUE;
            for (Target t : layer) {
                if (t.done || t.skipped || t.auto || t.hard) continue;
                if (StateMatcher.matches(w.getBlockState(t.pos), t.state)) { t.done = true; continue; }
                double score = t.defers * 1.0e6 + dist2(t.pos, pp);
                if (score < bestScore) { bestScore = score; best = t; }
            }
            if (best != null) return best;   // finish the lowest unfinished layer first
        }
        return null;
    }

    private boolean finishOrSweep() {
        ClientWorld w = mc.world;
        int reopened = 0;
        for (List<Target> layer : plan.layers.values()) {
            for (Target t : layer) {
                if (t.auto || t.hard) continue;
                if (StateMatcher.matches(w.getBlockState(t.pos), t.state)) { t.done = true; continue; }
                if (sweepPass < 2) { t.done = false; t.skipped = false; t.defers = 0; t.attempts = 0; }
                reopened++;
            }
        }
        if (reopened > 0 && sweepPass < 2) {   // final sweep: pops, gravity, anything that went missing
            sweepPass++;
            return true;
        }
        requestStop(reopened == 0 ? "Build complete!" : "Finished, but " + reopened + " blocks could not be placed.");
        return false;
    }

    private boolean assess(ClientWorld w) {
        Target t = cur;
        if (t == null) { state = State.PICK; return true; }
        BlockState now = w.getBlockState(t.pos);
        if (StateMatcher.matches(now, t.state)) { t.done = true; state = State.PICK; return true; }
        if (!now.isReplaceable()) {
            if (cfg().replaceMode && now.getHardness(w, t.pos) >= 0) {
                breakQueue.add(t.pos);
                startBreaking(State.ASSESS);
                return true;
            }
            skip(t, "position occupied by " + now.getBlock().getName().getString());
            return true;
        }
        if (!t.state.canPlaceAt(w, t.pos)) { defer(t); return true; }
        if (t.state.getBlock() instanceof FallingBlock
                && !w.getBlockState(t.pos.down()).isSideSolidFullSquare(w, t.pos.down(), Direction.UP)) {
            defer(t);
            return true;
        }
        Item item = t.state.getBlock().asItem();
        boolean freestanding = PlacementSolver.isFreestanding(t.state, w, t.pos);
        Set<BlockPos> excluded = freestanding ? null : new HashSet<>(activeScaffolds);

        if (PlacementSolver.hasSupport(w, t.pos, excluded)) {
            if (PlacementSolver.solve(mc, t.state, t.pos, 99, excluded, false) == null) { defer(t); return true; }
            startJob(t.pos, t.state, false, item);
            return true;
        }
        if (!freestanding) { defer(t); return true; }   // needs a real block to attach to

        // nothing to place against: build a scaffold chain
        Item tempItem = InventoryHelper.pickTempItem(mc, cfg());
        if (tempItem == null) {
            requestPause("no temporary blocks in inventory " + cfg().tempBlocks);
            return false;
        }
        List<BlockPos> chain = ScaffoldPlanner.plan(mc, t.pos, plan.byPos::containsKey, cfg().maxScaffoldDepth);
        if (chain == null) { defer(t); return true; }
        scaffoldQueue.clear();
        scaffoldQueue.addAll(chain);
        startJob(chain.get(0), ((BlockItem) tempItem).getBlock().getDefaultState(), true, tempItem);
        return true;
    }

    private void defer(Target t) {
        t.defers++;
        if (t.defers > 3) skip(t, "no way to place it right now");
        else state = State.PICK;
    }

    private void skip(Target t, String why) {
        t.skipped = true;
        SchematicBuilderMod.LOG.info("Skipped {} at {}: {}", t.state.getBlock().getName().getString(), t.pos.toShortString(), why);
        state = State.PICK;
    }

    // ---------------------------------------------------------------- jobs
    private void startJob(BlockPos pos, BlockState st, boolean temp, Item item) {
        jobPos = pos;
        jobState = st;
        jobTemp = temp;
        jobItem = item;
        sol = null;
        moveTicks = 0;
        state = State.SELECT_ITEM;
    }

    private PlacementSolver.Solution solveJob(boolean strict) {
        double reach = Math.min(cfg().reach, mc.player.getBlockInteractionRange());
        Set<BlockPos> excluded = null;
        if (!jobTemp && !PlacementSolver.isFreestanding(jobState, mc.world, jobPos)) excluded = new HashSet<>(activeScaffolds);
        return PlacementSolver.solve(mc, jobState, jobPos, reach, excluded, strict);
    }

    private void onJobSuccess() {
        if (jobTemp) {
            activeScaffolds.add(jobPos);
            scaffoldQueue.pollFirst();
            BlockPos next = scaffoldQueue.peekFirst();
            if (next != null) startJob(next, jobState, true, jobItem);
            else startJob(cur.pos, cur.state, false, cur.state.getBlock().asItem());
        } else {
            cur.done = true;
            state = State.PICK;
        }
    }

    private void jobFailed(String why) {
        SchematicBuilderMod.LOG.debug("Job failed: {}", why);
        scaffoldQueue.clear();
        if (cur == null) { state = State.PICK; return; }
        cur.attempts++;
        if (cur.attempts >= cfg().maxRetries) skip(cur, why);
        else state = State.ASSESS;
    }

    // ---------------------------------------------------------------- breaking (scaffolds / wrong blocks)
    private void startBreaking(State after) {
        afterBreak = after;
        state = State.BREAK_TEMP;
        breakingPos = null;
        breaking = false;
        moveTicks = 0;
    }

    private boolean breakStep(ClientWorld w) {
        BlockPos bp = breakQueue.peekFirst();
        if (bp == null) {
            mc.interactionManager.cancelBlockBreaking();
            releaseKeys();
            breakingPos = null;
            breaking = false;
            onBreakDone();
            return true;
        }
        if (!bp.equals(breakingPos)) {
            breakingPos = bp;
            breaking = false;
            moveTicks = 0;
            mc.interactionManager.cancelBlockBreaking();
        }
        BlockState bs = w.getBlockState(bp);
        if (bs.isAir() || bs.isReplaceable()) {
            breakQueue.pollFirst();
            activeScaffolds.remove(bp);
            return true;
        }
        Vec3d c = Vec3d.ofCenter(bp);
        Vec3d eye = mc.player.getEyePos();
        double reach = Math.min(cfg().reach, mc.player.getBlockInteractionRange());
        if (eye.distanceTo(c) > reach - 0.3) {
            walkToward(c);
            if (++moveTicks > 200) {
                leftovers.add(bp);
                breakQueue.pollFirst();
                activeScaffolds.remove(bp);
            }
            return false;
        }
        releaseKeys();
        lookAt(c);
        if (cfg().autoSwitchTool) InventoryHelper.selectBestTool(mc, bs);
        Direction side = Direction.getFacing(eye.x - c.x, eye.y - c.y, eye.z - c.z);
        if (!breaking) {
            mc.interactionManager.attackBlock(bp, side);
            breaking = true;
        } else {
            mc.interactionManager.updateBlockBreakingProgress(bp, side);
        }
        mc.player.swingHand(Hand.MAIN_HAND);
        return false;
    }

    private void onBreakDone() {
        if (mode == Mode.PAUSING) {
            mode = Mode.PAUSED;
            state = State.IDLE;
            msg("Paused. Temporary blocks removed. /build resume to continue.");
            reportLeftovers();
        } else if (mode == Mode.STOPPING) {
            mode = Mode.IDLE;
            state = State.IDLE;
            msg(stopMessage);
            reportLeftovers();
        } else {
            state = afterBreak;
        }
    }

    // ---------------------------------------------------------------- pause / stop / cleanup
    private void requestPause(String reason) {
        if (mode != Mode.RUNNING) return;
        msg("Pausing: " + reason);
        mode = Mode.PAUSING;
        beginCleanup();
    }

    private void requestStop(String message) {
        if (mode == Mode.IDLE || mode == Mode.STOPPING) return;
        stopMessage = message;
        mode = Mode.STOPPING;
        beginCleanup();
    }

    /** Queue every temp block for removal, then idle/pause when the queue is empty. */
    private void beginCleanup() {
        releaseKeys();
        scaffoldQueue.clear();
        sol = null;
        breakQueue.clear();
        breakQueue.addAll(activeScaffolds);
        startBreaking(State.IDLE);
        cooldown = 0;
        if (mc != null && mc.interactionManager != null) mc.interactionManager.cancelBlockBreaking();
    }

    private void forceIdle() {
        mode = Mode.IDLE;
        state = State.IDLE;
        releaseKeys();
        scaffoldQueue.clear();
        breakQueue.clear();
        cur = null;
    }

    private void reportLeftovers() {
        List<BlockPos> left = new ArrayList<>(leftovers);
        left.addAll(activeScaffolds);
        if (!left.isEmpty()) {
            StringBuilder sb = new StringBuilder("Could not remove temporary blocks at:");
            for (BlockPos p : left) sb.append(' ').append(p.toShortString()).append(';');
            msg(sb.toString());
        }
        leftovers.clear();
        activeScaffolds.clear();
    }

    // ---------------------------------------------------------------- movement helpers
    /** Straight-line steering with auto-jump. Not real pathfinding. */
    private void walkToward(Vec3d goal) {
        ClientPlayerEntity p = mc.player;
        double dx = goal.x - p.getX(), dz = goal.z - p.getZ();
        double dist = Math.sqrt(dx * dx + dz * dz);
        p.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        boolean flying = p.getAbilities().flying;
        mc.options.forwardKey.setPressed(dist > 1.2);
        mc.options.jumpKey.setPressed((p.horizontalCollision && p.isOnGround()) || (flying && goal.y + 1 > p.getY() + 1.5));
        mc.options.sneakKey.setPressed(flying && goal.y + 1 < p.getY() - 2.5);
    }

    private void lookAt(Vec3d t) {
        Vec3d e = mc.player.getEyePos();
        double dx = t.x - e.x, dy = t.y - e.y, dz = t.z - e.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        mc.player.setYaw((float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0));
        mc.player.setPitch((float) -Math.toDegrees(Math.atan2(dy, h)));
    }

    private void releaseKeys() {
        if (mc == null || mc.options == null) return;
        mc.options.forwardKey.setPressed(false);
        mc.options.jumpKey.setPressed(false);
        mc.options.sneakKey.setPressed(false);
    }

    // ---------------------------------------------------------------- stats
    private void refreshStats() {
        if (plan == null || mc == null || mc.world == null || mc.player == null) return;
        ClientWorld w = mc.world;
        Vec3d pp = mc.player.getPos();
        int total = 0, done = 0, firstY = Integer.MIN_VALUE;
        Map<Item, Integer> need = new HashMap<>();
        List<BlockPos> pv = new ArrayList<>();
        for (List<Target> layer : plan.layers.values()) {
            for (Target t : layer) {
                if (t.auto || t.hard) continue;
                total++;
                if (StateMatcher.matches(w.getBlockState(t.pos), t.state)) { done++; continue; }
                need.merge(t.state.getBlock().asItem(), 1, Integer::sum);
                if (firstY == Integer.MIN_VALUE) firstY = t.pos.getY();
                if (pv.size() < 300 && t.pos.getY() <= firstY + 1 && dist2(t.pos, pp) < 64 * 64) pv.add(t.pos);
            }
        }
        Map<String, Integer> miss = new LinkedHashMap<>();
        if (!mc.player.isCreative()) {
            for (Map.Entry<Item, Integer> e : need.entrySet()) {
                int have = mc.player.getInventory().count(e.getKey());
                if (have < e.getValue()) miss.put(e.getKey().getName().getString(), e.getValue() - have);
            }
        }
        statTotal = total;
        statDone = done;
        preview = pv;
        missing = miss;
    }

    private static double dist2(BlockPos p, Vec3d v) {
        double dx = p.getX() + 0.5 - v.x, dy = p.getY() + 0.5 - v.y, dz = p.getZ() + 0.5 - v.z;
        return dx * dx + dy * dy + dz * dz;
    }

    private void msg(String s) {
        if (mc != null && mc.player != null) mc.player.sendMessage(Text.literal("[Builder] " + s), false);
    }
}
