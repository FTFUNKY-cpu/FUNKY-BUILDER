package com.example.schematicbuilder.schematic;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

import java.util.List;

/** Non-air blocks with positions relative to the schematic's minimum corner. */
public record Schematic(String name, int sizeX, int sizeY, int sizeZ, List<Entry> blocks) {
    public record Entry(BlockPos pos, BlockState state) {}
}
