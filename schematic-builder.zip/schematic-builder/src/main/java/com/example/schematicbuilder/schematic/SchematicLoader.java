package com.example.schematicbuilder.schematic;

import com.example.schematicbuilder.SchematicBuilderMod;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Stream;

public final class SchematicLoader {
    private static final Set<String> UNKNOWN = new HashSet<>();

    /** Put schematic files in <game dir>/schematics */
    public static Path dir() {
        Path p = FabricLoader.getInstance().getGameDir().resolve("schematics");
        try { Files.createDirectories(p); } catch (IOException ignored) {}
        return p;
    }

    public static List<String> list() {
        try (Stream<Path> s = Files.list(dir())) {
            return s.map(p -> p.getFileName().toString())
                    .filter(n -> n.endsWith(".schem") || n.endsWith(".litematic"))
                    .sorted().toList();
        } catch (IOException e) {
            return List.of();
        }
    }

    public static Schematic load(String file) throws IOException {
        Path p = dir().resolve(file).normalize();
        if (!p.startsWith(dir())) throw new IOException("Invalid path");
        if (!Files.exists(p)) throw new IOException("File not found: " + p);
        String n = file.toLowerCase(Locale.ROOT);
        if (!n.endsWith(".schem") && !n.endsWith(".litematic")) throw new IOException("Unsupported format (use .schem or .litematic)");
        NbtCompound root = NbtIo.readCompressed(p, NbtSizeTracker.ofUnlimitedBytes());
        return n.endsWith(".litematic") ? litematic(file, root) : sponge(file, root);
    }

    // ---------------------------------------------------------------- Sponge (.schem) v2 + v3
    private static Schematic sponge(String name, NbtCompound root) throws IOException {
        NbtCompound s = root.contains("Schematic", NbtElement.COMPOUND_TYPE) ? root.getCompound("Schematic") : root;
        int w = s.getShort("Width") & 0xFFFF, h = s.getShort("Height") & 0xFFFF, l = s.getShort("Length") & 0xFFFF;
        NbtCompound palNbt;
        byte[] data;
        if (s.contains("Blocks", NbtElement.COMPOUND_TYPE)) {            // v3
            NbtCompound b = s.getCompound("Blocks");
            palNbt = b.getCompound("Palette");
            data = b.getByteArray("Data");
        } else {                                                          // v2
            palNbt = s.getCompound("Palette");
            data = s.getByteArray("BlockData");
        }
        if (w == 0 || h == 0 || l == 0 || data.length == 0) throw new IOException("Empty or unreadable .schem");

        Map<Integer, BlockState> palette = new HashMap<>();
        for (String key : palNbt.getKeys()) palette.put(palNbt.getInt(key), parseState(key));

        List<Schematic.Entry> out = new ArrayList<>();
        int i = 0, idx = 0, total = w * h * l;
        while (i < data.length && idx < total) {
            int value = 0, shift = 0, b;
            do {
                b = data[i++];
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0 && i < data.length);
            BlockState st = palette.get(value);
            if (st != null && !st.isAir()) {
                int x = idx % w, z = (idx / w) % l, y = idx / (w * l);
                out.add(new Schematic.Entry(new BlockPos(x, y, z), st));
            }
            idx++;
        }
        return new Schematic(name, w, h, l, out);
    }

    // ---------------------------------------------------------------- Litematica (.litematic)
    private record Region(int ox, int oy, int oz, int sx, int sy, int sz, BlockState[] palette, long[] bits) {}

    private static Schematic litematic(String name, NbtCompound root) throws IOException {
        NbtCompound regions = root.getCompound("Regions");
        List<Region> list = new ArrayList<>();
        int minX = Integer.MAX_VALUE, minY = Integer.MAX_VALUE, minZ = Integer.MAX_VALUE;
        int maxX = Integer.MIN_VALUE, maxY = Integer.MIN_VALUE, maxZ = Integer.MIN_VALUE;

        for (String key : regions.getKeys()) {
            NbtCompound r = regions.getCompound(key);
            NbtCompound pos = r.getCompound("Position"), size = r.getCompound("Size");
            int px = pos.getInt("x"), py = pos.getInt("y"), pz = pos.getInt("z");
            int sx = size.getInt("x"), sy = size.getInt("y"), sz = size.getInt("z");
            // negative sizes extend backwards from Position
            int ox = sx < 0 ? px + sx + 1 : px, oy = sy < 0 ? py + sy + 1 : py, oz = sz < 0 ? pz + sz + 1 : pz;
            int ax = Math.abs(sx), ay = Math.abs(sy), az = Math.abs(sz);

            NbtList palNbt = r.getList("BlockStatePalette", NbtElement.COMPOUND_TYPE);
            BlockState[] palette = new BlockState[palNbt.size()];
            for (int i = 0; i < palette.length; i++) {
                NbtCompound e = palNbt.getCompound(i);
                Map<String, String> props = new HashMap<>();
                if (e.contains("Properties", NbtElement.COMPOUND_TYPE)) {
                    NbtCompound pr = e.getCompound("Properties");
                    for (String k : pr.getKeys()) props.put(k, pr.getString(k));
                }
                palette[i] = build(e.getString("Name"), props);
            }
            list.add(new Region(ox, oy, oz, ax, ay, az, palette, r.getLongArray("BlockStates")));
            minX = Math.min(minX, ox); minY = Math.min(minY, oy); minZ = Math.min(minZ, oz);
            maxX = Math.max(maxX, ox + ax); maxY = Math.max(maxY, oy + ay); maxZ = Math.max(maxZ, oz + az);
        }
        if (list.isEmpty()) throw new IOException("No regions in .litematic");

        List<Schematic.Entry> out = new ArrayList<>();
        for (Region g : list) {
            if (g.palette.length == 0) continue;
            int bits = Math.max(2, 32 - Integer.numberOfLeadingZeros(g.palette.length - 1));
            long mask = (1L << bits) - 1;
            long total = (long) g.sx * g.sy * g.sz;
            for (int idx = 0; idx < total; idx++) {
                int v = (int) readBits(g.bits, idx, bits, mask);
                if (v >= g.palette.length) continue;
                BlockState st = g.palette[v];
                if (st.isAir()) continue;
                int x = idx % g.sx, z = (idx / g.sx) % g.sz, y = idx / (g.sx * g.sz);
                out.add(new Schematic.Entry(new BlockPos(g.ox + x - minX, g.oy + y - minY, g.oz + z - minZ), st));
            }
        }
        return new Schematic(name, maxX - minX, maxY - minY, maxZ - minZ, out);
    }

    private static long readBits(long[] a, int index, int bits, long mask) {
        long start = (long) index * bits;
        int i0 = (int) (start >>> 6);
        int i1 = (int) ((((long) index + 1) * bits - 1) >>> 6);
        int off = (int) (start & 63);
        if (i0 >= a.length) return 0;
        if (i0 == i1) return (a[i0] >>> off) & mask;
        long hi = i1 < a.length ? a[i1] : 0;
        return ((a[i0] >>> off) | (hi << (64 - off))) & mask;
    }

    // ---------------------------------------------------------------- block state parsing
    static BlockState parseState(String s) {
        String name = s;
        Map<String, String> props = new HashMap<>();
        int br = s.indexOf('[');
        if (br >= 0 && s.endsWith("]")) {
            name = s.substring(0, br);
            for (String kv : s.substring(br + 1, s.length() - 1).split(",")) {
                int eq = kv.indexOf('=');
                if (eq > 0) props.put(kv.substring(0, eq).trim(), kv.substring(eq + 1).trim());
            }
        }
        return build(name, props);
    }

    static BlockState build(String name, Map<String, String> props) {
        Identifier id = Identifier.tryParse(name);
        if (id == null || !Registries.BLOCK.containsId(id)) {
            if (UNKNOWN.add(name)) SchematicBuilderMod.LOG.warn("Unknown block in schematic: {}", name);
            return Blocks.AIR.getDefaultState();
        }
        BlockState st = Registries.BLOCK.get(id).getDefaultState();
        for (Map.Entry<String, String> e : props.entrySet()) {
            Property<?> p = st.getBlock().getStateManager().getProperty(e.getKey());
            if (p != null) st = withProp(st, p, e.getValue());
        }
        return st;
    }

    private static <T extends Comparable<T>> BlockState withProp(BlockState st, Property<T> p, String v) {
        return p.parse(v).map(val -> st.with(p, val)).orElse(st);
    }
}
