package com.example.schematicbuilder.planner;

import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;

public final class Target {
    public final BlockPos pos;
    public final BlockState state;
    public boolean done, skipped;
    public boolean auto;   // placed together with its other half (door top, bed head, tall plant top)
    public boolean hard;   // this mod can never place it (double slab, fluid, no item form)
    public int attempts, defers;

    public Target(BlockPos pos, BlockState state) {
        this.pos = pos;
        this.state = state;
    }
}
