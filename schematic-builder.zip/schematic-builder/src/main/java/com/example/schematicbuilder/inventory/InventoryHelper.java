package com.example.schematicbuilder.inventory;

import com.example.schematicbuilder.config.BuilderConfig;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Identifier;

public final class InventoryHelper {

    /** Puts the item in the main hand: hotbar select, swap from inventory, or (creative) spawn it. */
    public static boolean ensureInHand(MinecraftClient mc, Item item) {
        ClientPlayerEntity p = mc.player;
        PlayerInventory inv = p.getInventory();
        if (p.getMainHandStack().isOf(item)) return true;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) { inv.selectedSlot = i; return true; }
        }
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(item)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, inv.selectedSlot, SlotActionType.SWAP, p);
                return p.getMainHandStack().isOf(item);
            }
        }
        if (p.isCreative()) {
            ItemStack st = new ItemStack(item, item.getMaxCount());
            inv.setStack(inv.selectedSlot, st);
            mc.interactionManager.clickCreativeStack(st, 36 + inv.selectedSlot);
            return true;
        }
        return false;
    }

    /** First configured temp block the player has (any, in creative). */
    public static Item pickTempItem(MinecraftClient mc, BuilderConfig cfg) {
        boolean creative = mc.player.isCreative();
        for (String id : cfg.tempBlocks) {
            Identifier i = Identifier.tryParse(id);
            if (i == null) continue;
            Item it = Registries.ITEM.get(i);
            if (!(it instanceof BlockItem)) continue;
            if (creative || mc.player.getInventory().count(it) > 0) return it;
        }
        return null;
    }

    public static void selectBestTool(MinecraftClient mc, BlockState s) {
        PlayerInventory inv = mc.player.getInventory();
        int best = inv.selectedSlot;
        float bestSpeed = inv.getStack(best).getMiningSpeedMultiplier(s);
        for (int i = 0; i < 9; i++) {
            float f = inv.getStack(i).getMiningSpeedMultiplier(s);
            if (f > bestSpeed) { bestSpeed = f; best = i; }
        }
        inv.selectedSlot = best;
    }
}
