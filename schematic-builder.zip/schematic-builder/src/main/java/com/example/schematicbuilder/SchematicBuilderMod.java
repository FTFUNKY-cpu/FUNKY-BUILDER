package com.example.schematicbuilder;

import com.example.schematicbuilder.command.BuildCommand;
import com.example.schematicbuilder.config.BuilderConfig;
import com.example.schematicbuilder.executor.BuildExecutor;
import com.example.schematicbuilder.render.HudRenderer;
import com.example.schematicbuilder.render.OverlayRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class SchematicBuilderMod implements ClientModInitializer {
    public static final String MOD_ID = "schematicbuilder";
    public static final Logger LOG = LoggerFactory.getLogger(MOD_ID);

    public static BuilderConfig config;
    public static BuildExecutor executor;

    @Override
    public void onInitializeClient() {
        config = BuilderConfig.load();
        executor = new BuildExecutor();

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> BuildCommand.register(dispatcher));
        ClientTickEvents.END_CLIENT_TICK.register(executor::tick);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> executor.onDisconnect());
        HudRenderCallback.EVENT.register(HudRenderer::render);
        // The overlay uses rendering APIs that change between Minecraft versions.
        // If it fails to compile on your version, delete this one line.
        WorldRenderEvents.AFTER_TRANSLUCENT.register(OverlayRenderer::render);
    }
}
