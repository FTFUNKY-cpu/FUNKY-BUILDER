package com.example.schematicbuilder.planner;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import java.util.*;
import java.util.function.Predicate;

/**
 * Breadth-first search for the shortest chain of free (air) positions that starts next to the
 * target and ends next to a real block. Returned in PLACEMENT order (anchored end first).
 */
public final class ScaffoldPlanner {
    private static final Direction[] ORDER = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};

    public static List<BlockPos> plan(MinecraftClient mc, BlockPos target, Predicate<BlockPos> reserved, int maxDepth) {
        ClientWorld w = mc.world;
        Box me = mc.player.getBoundingBox();
        Set<BlockPos> seen = new HashSet<>();
        seen.add(target);
        Deque<List<BlockPos>> queue = new ArrayDeque<>();
        for (Direction d : ORDER) {
            BlockPos s = target.offset(d);
            if (seen.add(s) && free(w, s, me, reserved)) queue.add(List.of(s));
        }
        while (!queue.isEmpty()) {
            List<BlockPos> chain = queue.poll();
            BlockPos last = chain.get(chain.size() - 1);
            if (PlacementSolver.hasSupport(w, last, null)) {
                List<BlockPos> result = new ArrayList<>(chain);
                Collections.reverse(result);
                return result;
            }
            if (chain.size() >= maxDepth) continue;
            for (Direction d : ORDER) {
                BlockPos n = last.offset(d);
                if (seen.add(n) && free(w, n, me, reserved)) {
                    List<BlockPos> c = new ArrayList<>(chain);
                    c.add(n);
                    queue.add(c);
                }
            }
        }
        return null;
    }

    private static boolean free(ClientWorld w, BlockPos p, Box me, Predicate<BlockPos> reserved) {
        return w.getBlockState(p).isReplaceable() && !reserved.test(p) && !me.intersects(new Box(p));
    }
}
