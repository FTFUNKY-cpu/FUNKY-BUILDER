package com.example.schematicbuilder.command;

import com.example.schematicbuilder.SchematicBuilderMod;
import com.example.schematicbuilder.config.BuilderConfig;
import com.example.schematicbuilder.executor.BuildExecutor;
import com.example.schematicbuilder.planner.BuildPlan;
import com.example.schematicbuilder.schematic.Schematic;
import com.example.schematicbuilder.schematic.SchematicLoader;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.minecraft.client.MinecraftClient;
import net.minecraft.command.CommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.util.List;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public final class BuildCommand {
    private static final SuggestionProvider<FabricClientCommandSource> FILES =
            (c, b) -> CommandSource.suggestMatching(SchematicLoader.list(), b);

    public static void register(CommandDispatcher<FabricClientCommandSource> d) {
        d.register(literal("build")
                .then(literal("list").executes(c -> list(c.getSource())))
                .then(literal("load").then(argument("file", StringArgumentType.greedyString()).suggests(FILES)
                        .executes(c -> load(c.getSource(), StringArgumentType.getString(c, "file")))))
                .then(literal("origin")
                        .then(literal("here").executes(c -> originHere(c.getSource())))
                        .then(literal("look").executes(c -> originLook(c.getSource()))))
                .then(literal("rotate").then(argument("degrees", IntegerArgumentType.integer(0, 270))
                        .executes(c -> rotate(c.getSource(), IntegerArgumentType.getInteger(c, "degrees")))))
                .then(literal("mirror").executes(c -> mirror(c.getSource())))
                .then(literal("start").executes(c -> start(c.getSource())))
                .then(literal("pause").executes(c -> { ex().pause(); return 1; }))
                .then(literal("resume").executes(c -> resume(c.getSource())))
                .then(literal("stop").executes(c -> { ex().stop(); return 1; }))
                .then(literal("status").executes(c -> ok(c.getSource(), ex().plan() == null ? "No schematic loaded." : ex().status())))
                .then(literal("reload").executes(c -> {
                    SchematicBuilderMod.config = BuilderConfig.load();
                    return ok(c.getSource(), "Config reloaded.");
                })));
    }

    private static BuildExecutor ex() { return SchematicBuilderMod.executor; }
    private static MinecraftClient mc() { return MinecraftClient.getInstance(); }

    private static int ok(FabricClientCommandSource s, String m) { s.sendFeedback(Text.literal("[Builder] " + m)); return 1; }
    private static int err(FabricClientCommandSource s, String m) { s.sendError(Text.literal("[Builder] " + m)); return 0; }

    private static int list(FabricClientCommandSource s) {
        List<String> files = SchematicLoader.list();
        if (files.isEmpty()) return ok(s, "No schematics. Put .schem/.litematic files in " + SchematicLoader.dir());
        return ok(s, "Schematics: " + String.join(", ", files));
    }

    private static int load(FabricClientCommandSource s, String file) {
        try {
            Schematic sc = SchematicLoader.load(file);
            if (!ex().load(mc(), sc)) return err(s, "Stop the current build first.");
            BuildPlan p = ex().plan();
            ok(s, "Loaded " + file + ": " + sc.blocks().size() + " blocks, size "
                    + sc.sizeX() + "x" + sc.sizeY() + "x" + sc.sizeZ() + ". Origin = your position.");
            for (String w : p.warnings) ok(s, "Skipping " + w);
            return ok(s, "Adjust with /build origin|rotate|mirror, then /build start.");
        } catch (IOException | RuntimeException e) {
            SchematicBuilderMod.LOG.error("Load failed", e);
            return err(s, "Load failed: " + e.getMessage());
        }
    }

    private static int originHere(FabricClientCommandSource s) {
        if (!ex().setOrigin(mc().player.getBlockPos())) return err(s, "Load a schematic first (and stop any running build).");
        return ok(s, "Origin set to your position.");
    }

    private static int originLook(FabricClientCommandSource s) {
        HitResult hr = mc().crosshairTarget;
        if (!(hr instanceof BlockHitResult b) || b.getType() != HitResult.Type.BLOCK) return err(s, "Look at a block.");
        BlockPos p = b.getBlockPos().offset(b.getSide());
        if (!ex().setOrigin(p)) return err(s, "Load a schematic first (and stop any running build).");
        return ok(s, "Origin set to " + p.toShortString() + ".");
    }

    private static int rotate(FabricClientCommandSource s, int deg) {
        if (deg % 90 != 0) return err(s, "Use 0, 90, 180 or 270.");
        if (!ex().setRotation(deg / 90)) return err(s, "Load a schematic first (and stop any running build).");
        return ok(s, "Rotation " + deg + " degrees.");
    }

    private static int mirror(FabricClientCommandSource s) {
        if (!ex().toggleMirror()) return err(s, "Load a schematic first (and stop any running build).");
        return ok(s, "Mirror toggled.");
    }

    private static int start(FabricClientCommandSource s) {
        String e = ex().start(mc());
        return e != null ? err(s, e) : ok(s, "Building...");
    }

    private static int resume(FabricClientCommandSource s) {
        String e = ex().resume(mc());
        return e != null ? err(s, e) : ok(s, "Resumed.");
    }
}
