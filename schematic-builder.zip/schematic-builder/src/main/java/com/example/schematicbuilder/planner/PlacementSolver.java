package com.example.schematicbuilder.planner;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.ShapeContext;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.StairsBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * Finds a (support block, face, hit point, yaw, pitch) such that a normal right-click produces
 * exactly the wanted block state. It asks the real block class what state it would place
 * (Block#getPlacementState) for each candidate, so stairs/slabs/logs/etc. come out right.
 */
public final class PlacementSolver {
    public record Solution(BlockPos support, Direction face, Vec3d hit, float yaw, float pitch) {}

    private static final Direction[] ORDER = {Direction.DOWN, Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST, Direction.UP};
    private static final double[] TANGENT = {0.5, 0.2, 0.8};
    private static final double[] VERT = {0.5, 0.25, 0.75, 0.1, 0.9};

    public static boolean isSupport(ClientWorld w, BlockPos p, Set<BlockPos> excluded) {
        if (excluded != null && excluded.contains(p)) return false;
        BlockState s = w.getBlockState(p);
        return !s.isAir() && !s.isReplaceable() && s.getFluidState().isEmpty();
    }

    public static boolean hasSupport(ClientWorld w, BlockPos pos, Set<BlockPos> excluded) {
        for (Direction d : ORDER) if (isSupport(w, pos.offset(d), excluded)) return true;
        return false;
    }

    /** Blocks that stay put when the temporary block they were placed against is removed. */
    public static boolean isFreestanding(BlockState s, ClientWorld w, BlockPos p) {
        Block b = s.getBlock();
        return s.isFullCube(w, p) || b instanceof SlabBlock || b instanceof StairsBlock;
    }

    /**
     * @param strict true = must be within reach and visible from the player's eyes right now;
     *               false = only check that SOME way of placing this state exists.
     */
    public static Solution solve(MinecraftClient mc, BlockState wanted, BlockPos target, double reach,
                                 Set<BlockPos> excluded, boolean strict) {
        Item item = wanted.getBlock().asItem();
        if (!(item instanceof BlockItem bi)) return null;
        ClientPlayerEntity pl = mc.player;
        ClientWorld w = mc.world;
        ItemStack stack = new ItemStack(item);
        Vec3d eye = pl.getEyePos();
        float oldYaw = pl.getYaw(), oldPitch = pl.getPitch();
        try {
            for (Direction d : ORDER) {
                BlockPos sup = target.offset(d);
                if (!isSupport(w, sup, excluded)) continue;
                Direction face = d.getOpposite(); // face of the support block that touches the target
                for (Vec3d hit : hitPoints(sup, face)) {
                    if (strict && (eye.distanceTo(hit) > reach || !visible(w, pl, eye, hit, sup, face))) continue;
                    BlockHitResult bhr = new BlockHitResult(hit, face, sup, false);
                    for (float[] rot : rotations(eye, hit)) {
                        pl.setYaw(rot[0]);
                        pl.setPitch(rot[1]);
                        ItemPlacementContext ctx = new ItemPlacementContext(pl, Hand.MAIN_HAND, stack, bhr);
                        if (!ctx.canPlace() || !ctx.getBlockPos().equals(target)) break; // independent of rotation
                        BlockState pred = bi.getBlock().getPlacementState(ctx);
                        if (pred == null || !pred.canPlaceAt(w, target)) continue;
                        if (!w.canPlace(pred, target, ShapeContext.of(pl))) continue;
                        if (StateMatcher.matches(pred, wanted)) return new Solution(sup, face, hit, rot[0], rot[1]);
                    }
                }
            }
        } finally {
            pl.setYaw(oldYaw);
            pl.setPitch(oldPitch);
        }
        return null;
    }

    private static boolean visible(ClientWorld w, ClientPlayerEntity pl, Vec3d eye, Vec3d hit, BlockPos sup, Direction face) {
        Vec3d dir = hit.subtract(eye);
        if (dir.lengthSquared() < 1.0E-6) return false;
        Vec3d end = hit.add(dir.normalize().multiply(0.02));
        BlockHitResult r = w.raycast(new RaycastContext(eye, end, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, pl));
        return r.getType() == HitResult.Type.BLOCK && r.getBlockPos().equals(sup) && r.getSide() == face;
    }

    /** Points on the given face of the support block (several heights so slabs/stairs can pick top or bottom). */
    private static List<Vec3d> hitPoints(BlockPos sup, Direction face) {
        List<Vec3d> out = new ArrayList<>();
        boolean side = face.getAxis().isHorizontal();
        for (double a : TANGENT) {
            for (double b : side ? VERT : TANGENT) {
                double x, y, z;
                switch (face.getAxis()) {
                    case Y -> { x = a; y = face == Direction.UP ? 1 : 0; z = b; }
                    case X -> { x = face == Direction.EAST ? 1 : 0; y = b; z = a; }
                    default -> { x = a; y = b; z = face == Direction.SOUTH ? 1 : 0; }
                }
                out.add(new Vec3d(sup.getX() + x, sup.getY() + y, sup.getZ() + z));
            }
        }
        return out;
    }

    /** First option: look straight at the hit point. Then fixed yaw/pitch for rotation-dependent blocks. */
    private static List<float[]> rotations(Vec3d eye, Vec3d hit) {
        List<float[]> l = new ArrayList<>();
        double dx = hit.x - eye.x, dy = hit.y - eye.y, dz = hit.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        l.add(new float[]{(float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0), (float) -Math.toDegrees(Math.atan2(dy, h))});
        for (float pitch : new float[]{0f, 90f, -90f})
            for (float yaw : new float[]{0f, 90f, 180f, 270f}) l.add(new float[]{yaw, pitch});
        return l;
    }
}
