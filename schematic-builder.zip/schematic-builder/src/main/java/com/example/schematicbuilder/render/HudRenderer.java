package com.example.schematicbuilder.render;

import com.example.schematicbuilder.SchematicBuilderMod;
import com.example.schematicbuilder.executor.BuildExecutor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public final class HudRenderer {
    public static void render(DrawContext ctx, RenderTickCounter tick) {
        BuildExecutor ex = SchematicBuilderMod.executor;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (ex == null || !SchematicBuilderMod.config.showHud || ex.plan() == null || mc.options.hudHidden) return;

        int total = ex.statTotal(), done = ex.statDone();
        int pct = total == 0 ? 100 : (int) (100L * done / total);

        List<String> lines = new ArrayList<>();
        lines.add("Schematic: " + ex.plan().name);
        lines.add("Status: " + ex.mode() + (ex.mode() == BuildExecutor.Mode.IDLE ? "" : " (" + ex.state() + ")"));
        lines.add("Progress: " + done + " / " + total + " (" + pct + "%)");
        if (ex.current() != null && ex.mode() != BuildExecutor.Mode.IDLE) lines.add("Layer: y=" + ex.current().pos.getY());
        lines.add("Remaining: " + (total - done) + "   Temp blocks: " + ex.scaffolds().size());
        int shown = 0;
        for (Map.Entry<String, Integer> e : ex.missing().entrySet()) {
            if (shown++ == 0) lines.add("Missing:");
            if (shown > 4) { lines.add("  ..."); break; }
            lines.add("  " + e.getKey() + " x" + e.getValue());
        }
        int y = 6;
        for (String l : lines) {
            ctx.drawTextWithShadow(mc.textRenderer, l, 6, y, 0xFFFFFF);
            y += 10;
        }
    }
}
