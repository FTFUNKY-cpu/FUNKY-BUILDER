package com.example.schematicbuilder.render;

import com.example.schematicbuilder.SchematicBuilderMod;
import com.example.schematicbuilder.executor.BuildExecutor;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.VertexRendering;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

/**
 * Wireframe preview: yellow = schematic bounds, cyan = blocks still to place (lowest layers),
 * green = current target, orange = temporary scaffold blocks.
 * Rendering APIs change a lot between Minecraft versions; this is the most version-sensitive file.
 */
public final class OverlayRenderer {
    public static void render(WorldRenderContext ctx) {
        BuildExecutor ex = SchematicBuilderMod.executor;
        if (ex == null || ex.plan() == null || !SchematicBuilderMod.config.showOverlay) return;
        MatrixStack ms = ctx.matrixStack();
        VertexConsumerProvider vcp = ctx.consumers();
        if (ms == null || vcp == null) return;

        Vec3d cam = ctx.camera().getPos();
        VertexConsumer vc = vcp.getBuffer(RenderLayer.getLines());
        ms.push();
        ms.translate(-cam.x, -cam.y, -cam.z);

        VertexRendering.drawBox(ms, vc, ex.plan().bounds, 1f, 1f, 0f, 1f);
        for (BlockPos p : ex.preview()) VertexRendering.drawBox(ms, vc, new Box(p).contract(0.05), 0f, 0.9f, 1f, 0.7f);
        for (BlockPos p : ex.scaffolds()) VertexRendering.drawBox(ms, vc, new Box(p), 1f, 0.5f, 0f, 1f);
        if (ex.current() != null && ex.mode() == BuildExecutor.Mode.RUNNING)
            VertexRendering.drawBox(ms, vc, new Box(ex.current().pos).expand(0.01), 0f, 1f, 0f, 1f);

        ms.pop();
    }
}
