package com.example.schematicbuilder.planner;

import net.minecraft.block.BlockState;
import net.minecraft.state.property.Property;

import java.util.Set;

/**
 * Compares a world block with a wanted block. Properties that placement cannot control
 * (connections, power, open/closed, waterlogged...) are ignored.
 */
public final class StateMatcher {
    private static final Set<String> IGNORED = Set.of(
            "waterlogged", "powered", "open", "lit", "power", "delay", "distance", "persistent", "locked",
            "triggered", "attached", "north", "east", "south", "west", "up", "down", "shape", "hinge",
            "in_wall", "extended", "enabled", "has_book", "occupied", "stage", "age", "bites");

    public static boolean matches(BlockState actual, BlockState wanted) {
        if (actual.getBlock() != wanted.getBlock()) return false;
        for (Property<?> p : wanted.getProperties()) {
            if (IGNORED.contains(p.getName())) continue;
            if (!actual.get(p).equals(wanted.get(p))) return false;
        }
        return true;
    }
}
