package com.example.schematicbuilder.config;

import com.example.schematicbuilder.SchematicBuilderMod;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

/** Saved as config/schematicbuilder.json. Edit it and run /build reload. */
public class BuilderConfig {
    public int placeDelayTicks = 2;        // pause after each placed/broken block
    public int verifyDelayTicks = 5;       // wait for the server to confirm a placement
    public int maxStepsPerTick = 4;        // max state-machine transitions per tick
    public double reach = 4.5;
    public List<String> tempBlocks = new ArrayList<>(List.of("minecraft:cobblestone", "minecraft:dirt", "minecraft:netherrack"));
    public int maxScaffoldDepth = 3;       // longest chain of temp blocks
    public int maxRetries = 3;
    public boolean autoSwitchTool = true;
    public boolean replaceMode = false;    // break wrong blocks and replace them
    public boolean pauseOnDamage = true;
    public boolean pauseOnScreen = true;
    public boolean pauseOnManualMove = true;
    public boolean showHud = true;
    public boolean showOverlay = true;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("schematicbuilder.json");
    }

    public static BuilderConfig load() {
        Path p = path();
        try {
            if (Files.exists(p)) {
                BuilderConfig c = GSON.fromJson(Files.readString(p), BuilderConfig.class);
                if (c != null) return c;
            }
        } catch (Exception e) {
            SchematicBuilderMod.LOG.warn("Could not read config, using defaults", e);
        }
        BuilderConfig c = new BuilderConfig();
        c.save();
        return c;
    }

    public void save() {
        try {
            Files.writeString(path(), GSON.toJson(this));
        } catch (IOException e) {
            SchematicBuilderMod.LOG.warn("Could not save config", e);
        }
    }
}
