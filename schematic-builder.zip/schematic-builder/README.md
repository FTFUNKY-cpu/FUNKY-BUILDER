# Schematic Builder (Fabric, Minecraft 1.21.4, Java 21)

Client-side mod that builds .litematic / .schem schematics with your own player.
When a block has nothing to be placed against, it places a temporary block, places the real block, then breaks the temporary one.

## Build and run
1. Install JDK 21.
2. Add the Gradle wrapper (copy `gradlew`, `gradlew.bat`, `gradle/` from the Fabric example mod,
   or run `gradle wrapper --gradle-version 8.12` once if Gradle is installed).
3. `./gradlew runClient` to test, or `./gradlew build` -> `build/libs/schematic-builder-0.1.0.jar` for your mods folder.
4. Put schematics in `<minecraft dir>/schematics/`.

## Commands
/build list | load <file> | origin here | origin look | rotate <0|90|180|270> | mirror
/build start | pause | resume | stop | status | reload

The origin is the minimum corner of the (rotated/mirrored) schematic.
Config: `config/schematicbuilder.json` (then /build reload).

## Limitations
- Compiled against Yarn 1.21.4. 1.21.5+ changed NBT getters, PlayerInventory.selectedSlot, and rendering; those need small edits.
- Movement is straight-line steering with auto-jump, not real pathfinding (no Baritone hook yet).
- Double slabs, fluids and fire are skipped. Open/closed doors, redstone power, fence/wall connections are not controlled.
- Blocks that attach to a face (torches, buttons, ladders) are only placed against real blocks, never scaffolds.
- Anti-cheat servers (Grim, etc.) may flag automated placing. Use only where allowed.
- Mod Menu / Cloth Config screen not included; edit the JSON.
- OverlayRenderer uses rendering APIs that change often; if it fails to compile, delete its registration line in SchematicBuilderMod.
